//: Playground - noun: a place where people can play

// This playground excerpts From: 
// Apple Inc. “The Swift Programming Language (Swift 3).”
// iBooks. https://itun.es/us/jEUH0.l

import UIKit

var str = "Hello, playground"

// “NOTE
// Optional chaining in Swift is similar to messaging nil in Objective-C, but in a way that works for any type, and that can be checked for success or failure.”

// Optional Chaining as an Alternative to Forced Unwrapping
// p500
class Person {
    var residence: Residence?
}

class Residence {
    var numberOfRooms = 1
}

// p501
let john = Person()

// triggers a runtime error, there is no residence valie tp unwarp
//let  rootCount = john.residence!.numberOfRooms


// p502
// Because the attempt to access "numberOfRooms" ahs the potential to fail,
// the optional chaining attempt returns a value of type Int? or "optional Int"
if let rootCount = john.residence?.numberOfRooms {
    print(" John's residence has \(rootCount) room(s)")
} else {
    print("Unable to retrive the number of rooms")
}

// if we assign a "Residence" instance to "john,residence", so that it no longer
// has a nil value

// if tring to access "numberIfRooms" with the same optional chaining as before,
// kit will new return an Int? that contains the default "numberOfRooms" value of 1
john.residence = Residence()
if let rootCount = john.residence?.numberOfRooms {
    print(" John's residence has \(rootCount) room(s)")
} else {
    print("Unable to retrive the number of rooms")
}



// -------------------------------------------------------------------------------------
// Defining Model Classes for Optional Chaining
// p503
// “You can use optional chaining with calls to properties, methods, and subscripts that are more than one level deep. This enables you to drill down into subproperties within complex models of interrelated types, and to check whether it is possible to access properties, methods, and subscripts on those subproperties.”


class Person1 {
    var residence: Residence1?
}
// “As a shortcut to accessing its rooms array, this version of Residence1 provides a read-write subscript that provides access to the room at the requested index in the rooms array.”
class Residence1 {
    var rooms = [Room]()
    var numberOfRooms: Int {
        return rooms.count
    }
    subscript(i: Int) -> Room {
        get {
            return rooms[i]
        }
        set {
            rooms[i] = newValue
        }
    }
    func printNumberOfRooms() {
        print("The number if rooms is \(numberOfRooms)")
    }
    var address: Address?
}

class Room {
    let name: String
    init(name: String) {
        self.name = name
    }
}

class Address {
    var buildingName: String?
    
    var buildingNumber: String?
    var street: String?
    
    func buildingIdentifier() -> String? {
        if buildingName != nil {
            return buildingName
        } else if buildingNumber != nil && street != nil {
            return "\(buildingNumber) \(street)"
        } else {
            return nil
        }
    }
}





// p508
let john1 = Person1()
// “Because john.residence is nil, this optional chaining call fails in the same way as before.”
if let rootCount = john1.residence?.numberOfRooms {
    print(" John's residence has \(rootCount) room(s)")
} else {
    print("Unable to retrive the number of rooms")
}

// “In this example, the attempt to set the address property of john.residence will fail, because john.residence is currently nil.”

// “The assignment is part of the optional chaining, which means none of the code on the right hand side of the = operator is evaluated. ”

let someAddress = Address()
someAddress.buildingNumber = "29"
someAddress.street = "Acacia Road"
john1.residence?.address = someAddress

if let count = john1.residence?.address?.buildingNumber  {
    print(" John's address has \(count)")
} else {
    print("Unable to retrive the buildingNumber")
}


// p509
// “The assignment is part of the optional chaining, which means none of the code on the right hand side of the = operator is evaluated. ”
// It is so, even if we use a function to create the "residence?.address"
func createAddress() -> Address{
    print("Function was called.")
    
    let someAddress = Address()
    
    someAddress.buildingNumber = "29"
    someAddress.street = "Acacia Road"
    return someAddress
}

john1.residence?.address = createAddress()


// -------------------------------------------------------------------------------------
// Calling Methods Through Optional Chaining
// p510

// “If you call this method on an optional value with optional chaining, the method’s return type will be Void?, not Void, because return values are always of an optional type when called through optional chaining. This enables you to use an if statement to check whether it was possible to call the printNumberOfRooms() method, even though the method does not itself define a return value. ”

// look the "func printNumberOfRooms()" in Residence1
if john1.residence?.printNumberOfRooms() != nil {
    print("It was possible to print the number of rooms.")
} else {
    print("It was not possible to print the numbe of rooms.")
}

// p511
// “The same is true if you attempt to set a property through optional chaining. The example above in Accessing Properties Through Optional Chaining attempts to set an address value for john.residence, even though the residence property is nil. Any attempt to set a property through optional chaining returns a value of type Void?, which enables you to compare against nil to see if the property was set successfully:”
if (john1.residence?.address = someAddress) != nil {
    print("It was possible to set the address.")
} else {
    print("It was not possible to set the address.")
}


// -------------------------------------------------------------------------------------
// p512
// Accessing Subscripts Through Opeional Chaining

// “NOTE
// When you access a subscript on an optional value through optional chaining, you place the question mark before the subscript’s brackets, not after. The optional chaining question mark always follows immediately after the part of the expression that is optional.”

// “The optional chaining question mark in this subscript call is placed immediately after john.residence, before the subscript brackets, because john.residence is the optional value on which optional chaining is being attempted.”
if let firstRoomname = john1.residence?[0].name {
    print("The first room name is \(firstRoomname).")
} else {
    print("Unable to retrieve the first room name")
}

// “Similarly, you can try to set a new value through a subscript with optional chaining:”
john1.residence?[0] = Room(name: "Bathroom")


// p514
// “If you create and assign an actual Residence instance to john.residence, with one or more Room instances in its rooms array, you can use the Residence subscript to access the actual items in the rooms array through optional chaining:”

let johnsHouse = Residence1()
johnsHouse.rooms.append(Room(name: "Living Room"))
johnsHouse.rooms.append(Room(name: "Kitchen"))
john1.residence = johnsHouse
if let firstRoomname = john1.residence?[0].name {
    print("The first room name is \(firstRoomname).")
} else {
    print("Unable to retrieve the first room name")
}


// -------------------------------------------------------------------------------------
// Accessing Subscripts of Opeional Type
// p514
var testScores = [
    "Dave": [86, 82, 84],
    "Bev": [79, 94, 81],
]
testScores["Dace"]?[0] = 91
testScores["Bev"]?[0] += 1
testScores["Brain"]?[0] = 72 // "testScores" did contain the key "Brain"



// -------------------------------------------------------------------------------------
// Linking Multiple Levels of Chaining
// p515
// “You can link together multiple levels of optional chaining to drill down to properties, methods, and subscripts deeper within a model. However, multiple levels of optional chaining do not add more levels of optionality to the returned value.”

// “To put it another way:
//     If the type you are trying to retrieve is not optional, it will become optional because of the optional chaining.
//     
//     If the type you are trying to retrieve is already optional, it will not become more optional because of the chaining.”

// “Therefore:
//      If you try to retrieve an Int value through optional chaining, an Int? is always returned, no matter how many levels of chaining are used.
//      Similarly, if you try to retrieve an Int? value through optional chaining, an Int? is always returned, no matter how many levels of chaining are used.”

if let johnsStreet = john1.residence?.address?.street {
    print("John's street name is \(johnsStreet).")
} else {
    print("Unable to retrieve the address.")
}

// p518
// “If you set an actual Address instance as the value for john.residence.address, and set an actual value for the address’s street property, you can access the value of the street property through multilevel optional chaining:”

let johnsAddress = Address()
johnsAddress.buildingName = "The larches"
johnsAddress.street = "Laurel Street"
john1.residence?.address = johnsAddress

if let johnsStreet = john1.residence?.address?.street {
    print("John's stree name is \(johnsStreet).")
} else {
    print(" Unable to retrieve the address.")
}

// -------------------------------------------------------------------------------------
// Chaining on Methods with Optional Return Values
// p518
// “The example below calls the Address class’s buildingIdentifier() method through optional chaining. This method returns a value of type String?. As described above, the ultimate return type of this method call after optional chaining is also String?:”
if let buildingIdentifier = john1.residence?.address?.buildingIdentifier() {
    print("John's building identifier is \(buildingIdentifier)")
}

// p519
// “If you want to perform further optional chaining on this method’s return value, place the optional chaining question mark after the method’s parentheses:”
if let beginsWithThe = john1.residence?.address?.buildingIdentifier()?.hasPrefix("The") {
    if beginsWithThe {
        print("John's building identifier begins with \"The\".")
    } else {
        print("John's building identifier does not begin with \"the\".")
    }
}


// “NOTE
// In the example above, you place the optional chaining question mark after the parentheses, because the optional value you are chaining on is the buildingIdentifier() method’s return value, and not the buildingIdentifier() method itself.”




