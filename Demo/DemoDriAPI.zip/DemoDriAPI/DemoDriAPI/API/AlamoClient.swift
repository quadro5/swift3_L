//
//  HTTPTools.swift
//  DemoDriAPI
//
//  Created by PSL on 5/10/17.
//  Copyright © 2017 PSL. All rights reserved.
//

import Foundation
import Alamofire

fileprivate let DriHost = "https://api.dribbble.com/v1/"
fileprivate let accessToken = "37ddfc23b82ae5cfc673bc92770caf17272407d0d07bce3c1840fc993a509667"

class AlamoClient {
    let host = DriHost
    let sessionManager = SessionManager.shared.mgr
    var currentRequest: DataRequest?
    
    func send(
        request: APIRequestInterface,
        success: @escaping (Data?, Int?) -> (),
        failure: @escaping (Error?) -> ()) {
    
        guard let urlRequest = buildRequest(with: request) else {
            assertionFailure("AlamoClient: fail to build URLRequest")
            return
        }
        sessionManager.adapter = AccessTokenAdapter(accessToken: accessToken)
        currentRequest = sessionManager.request(urlRequest).responseData { (response) in
            if let error = response.result.error {
                failure(error)
            } else {
                success(response.result.value, response.response?.statusCode)
            }
        }
    }
    
    func cancel() {
        currentRequest?.cancel()
    }
    
    func suspend() {
        currentRequest?.suspend()
    }
    
    func resume() {
        currentRequest?.resume()
    }
}

extension AlamoClient {
    fileprivate func buildRequest(with apiRequest: APIRequestInterface) -> URLRequest? {
        
        guard let path = apiRequest.path,
            let method = apiRequest.method else {
                return nil
        }
        
        let url = URL(string: host.appending(path))!
        var urlRequest = URLRequest(url: url)
        urlRequest.httpMethod = method
        urlRequest.cachePolicy = apiRequest.cachePolicy
        
        if let header = apiRequest.header {
            for (key, value) in header {
                urlRequest.setValue(value as? String, forHTTPHeaderField: key)
            }
        }
        
        if let body = apiRequest.body {
            urlRequest.httpBody = try? JSONSerialization.data(withJSONObject: body, options: [])
        }
        
        return urlRequest
    }
}
