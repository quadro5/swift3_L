//
//  APIRequest.swift
//  DemoDriAPI
//
//  Created by PSL on 5/10/17.
//  Copyright © 2017 PSL. All rights reserved.
//

import Foundation



protocol APIRequestInterface {
    
    // http request info
    var path: String? { get set }
    var method: String? { get set }
    var cachePolicy: URLRequest.CachePolicy { get set }
    var header: [String: Any]? { get set }
    var body: [String: Any]? { get set }
    
    // parser info
    // associatetype ResponseParser: Decodable
}


