//
//  APIBody.swift
//  DemoDriAPI
//
//  Created by PSL on 5/10/17.
//  Copyright © 2017 PSL. All rights reserved.
//

import Foundation

class APICachePolicy {
    static func build(with endpoint: APIEndpoints) -> URLRequest.CachePolicy {
        switch endpoint {
        case .activeUser:
            return URLRequest.CachePolicy.reloadIgnoringCacheData
        default:
            return URLRequest.CachePolicy.useProtocolCachePolicy
        }
    }
}
