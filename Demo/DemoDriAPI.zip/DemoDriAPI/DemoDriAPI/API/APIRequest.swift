//
//  RequestBuilder.swift
//  DemoDriAPI
//
//  Created by PSL on 5/10/17.
//  Copyright © 2017 PSL. All rights reserved.
//

import Foundation

class APIRequest: APIRequestInterface {
    
    var path: String?
    var method: String?
    var cachePolicy: URLRequest.CachePolicy
    var header: [String: Any]?
    var body: [String: Any]?
    
    init(with endpoint: APIEndpoints,
         header: [String: Any]? = nil,
         body: [String: Any]? = nil) {
        
        self.path = APIPath.build(with: endpoint)
        self.method = APIMethod.build(with: endpoint)
        self.cachePolicy = APICachePolicy.build(with: endpoint)
        self.header = header
        self.body = body
    }
}
