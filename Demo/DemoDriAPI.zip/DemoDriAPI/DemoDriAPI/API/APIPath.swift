//
//  APIPathBuilder.swift
//  DemoDriAPI
//
//  Created by PSL on 5/10/17.
//  Copyright © 2017 PSL. All rights reserved.
//

import Foundation

fileprivate struct Api {
    
    static let shots = "shots"
    static let like = "like"
    
    static let listLikes = "likes"
    static let listShots = "shots"
    static let listFollowers = "followers"
    static let listFollowing = "following"
    
    static let activeUser = "user"
    static let users = "users"
    
    static let comments = "comments"
    static let page = "?page="
    static let perPage = "&per_page="
    static let sort = "&sort="
    
    static let paraBegin = "?"
    static let paraBetween = "&"
}

class APIPath {
    static func build(with endpoint: APIEndpoints) -> String? {
        switch endpoint {
        case .likeShot(let shotID):
            return formString(like: shotID)
        case .checkLikeShot(let shotID):
            return formString(like: shotID)
        case .unlikeShot(let shotID):
            return formString(like: shotID)
            
        case .activeUser:
            return "\(Api.activeUser)"
        case .activeUserLikesByPage(let page):
            return "\(Api.activeUser)/\(Api.listLikes)\(Api.page)\(page)"
        case .activeUserShotsByPage(let page):
            return "\(Api.activeUser)/\(Api.listShots)\(Api.page)\(page)"
        case .activeUserFollowersByPage(let page):
            return "\(Api.activeUser)/\(Api.listFollowers)\(Api.page)\(page)"
        case .activeUserFollowingByPage(let page):
            return "\(Api.activeUser)/\(Api.listFollowing)\(Api.page)\(page)"
            
            
        case .listUserShotsByPage(let userID, let page):
            return formString(userShots: userID, page: page)
        case .listUserLikesByPage(let userID, let page):
            return formString(userLikes: userID, page: page)
        case .listUserFollowersByPage(let userID, let page):
            return formString(userFollowers: userID, page: page)
        case .listUserFollowingByPage(let userID, let page):
            return formString(userFollowing: userID, page: page)
            
        case .listShotsByPagePerpage(let page, let perPage):
            return formString(listShotsByPage: page, perPage: perPage)
        case .listShotsByPagePerpageCustomSearch(let page, let perPage, let sort):
            return formString(listShotsByPage: page, perPage: perPage, sort: sort)
            
        case .listShotCommentsByPage(let shotID, let page):
            return formString(listComments: shotID, page: page)
            
        case .likeComment(let shotID, let commentID):
            return formString(likeComment: shotID, commentID)
        case .unlikeComment(let shotID, let commentID):
            return formString(likeComment: shotID, commentID)
            
        default:
            return nil
        }
    }
    
    // form String for url
    private static func formString(like shotID: Int) -> String {
        let urlString = "\(Api.shots)/\(shotID)/\(Api.like)"
        return urlString
    }
    
    private static func formString(userLikes userID: Int, page: Int) -> String {
        let urlString = "\(Api.users)/\(userID)/\(Api.listLikes)\(Api.page)\(page)"
        return urlString
    }
    
    private static func formString(userShots userID: Int, page: Int) -> String {
        let urlString = "\(Api.users)/\(userID)/\(Api.listShots)\(Api.page)\(page)"
        return urlString
    }
    
    private static func formString(userFollowers userID: Int, page: Int) -> String {
        let urlString = "\(Api.users)/\(userID)/\(Api.listFollowers)\(Api.page)\(page)"
        return urlString
    }
    
    private static func formString(userFollowing userID: Int, page: Int) -> String {
        let urlString = "\(Api.users)/\(userID)/\(Api.listFollowing)\(Api.page)\(page)"
        return urlString
    }
    
    private static func formString(listShotsByPage page: Int, perPage: Int) -> String {
        let urlString = "\(Api.listShots)\(Api.page)\(page)\(Api.perPage)\(perPage)"
        return urlString
    }
    
    private static func formString(listShotsByPage page: Int, perPage: Int, sort: String) -> String {
        let urlString = "\(Api.listShots)\(Api.page)\(page)\(Api.perPage)\(perPage)\(Api.sort)\(sort)"
        return urlString
    }
    
    
    private static func formString(listComments shotID: Int) -> String {
        let urlString = "\(Api.shots)/\(shotID)/\(Api.comments)"
        return urlString
    }
    
    private static func formString(listComments shotID: Int, page: Int) -> String {
        let urlString = "\(Api.shots)/\(shotID)/\(Api.comments)\(Api.page)\(page)"
        return urlString
    }
    
    private static func formString(listLikesForComment shotID: Int, _ commentID: Int) -> String {
        let urlString = "\(Api.shots)/\(shotID)/\(Api.comments)/\(commentID)/\(Api.like)"
        return urlString
    }
    
    private static func formString(likeComment shotID: Int, _ commentID: Int) -> String {
        let urlString = "\(Api.shots)/\(shotID)/\(Api.comments)/\(commentID)/\(Api.like)"
        return urlString
    }    
}
