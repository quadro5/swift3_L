//
//  APIEndpoints.swift
//  DemoDriAPI
//
//  Created by PSL on 5/10/17.
//  Copyright © 2017 PSL. All rights reserved.
//

import Foundation


public enum APIEndpoints {
    
    case Error
    // Int: ID
    case likeShot(Int)
    case checkLikeShot(Int)
    case unlikeShot(Int)
    case activeUser
    
    // Int: page
    case activeUserLikesByPage(Int)
    case activeUserShotsByPage(Int)
    case activeUserFollowersByPage(Int)
    case activeUserFollowingByPage(Int)
    
    // Int: userID, page
    case listUserLikesByPage(Int, Int)
    case listUserShotsByPage(Int, Int)
    case listUserFollowersByPage(Int, Int)
    case listUserFollowingByPage(Int, Int)
    
    // Int: page, perpage
    case listShotsByPagePerpage(Int, Int)
    case listShotsByPagePerpageCustomSearch(Int, Int, String)

    // shotID, page
    case listShotCommentsByPage(Int, Int)
    
    // shotID, commentID
    case likeComment(Int, Int)
    case unlikeComment(Int, Int)
}
