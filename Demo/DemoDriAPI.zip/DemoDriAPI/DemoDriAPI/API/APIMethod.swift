//
//  APIMethod.swift
//  DemoDriAPI
//
//  Created by PSL on 5/10/17.
//  Copyright © 2017 PSL. All rights reserved.
//

import Foundation

enum APIHTTPMethod: String {
    case GET
    case POST
    case PUT
    case DELETE
}

class APIMethod {
    static func build(with endpoint: APIEndpoints) -> String? {
        switch endpoint {
            
        case .likeShot:
            return APIHTTPMethod.POST.rawValue
            
        case .checkLikeShot:
            return APIHTTPMethod.GET.rawValue
            
        case .unlikeShot:
            return APIHTTPMethod.DELETE.rawValue
            
        case .activeUser:
            return APIHTTPMethod.GET.rawValue
            
        case .activeUserLikesByPage,
             .activeUserShotsByPage,
             .activeUserFollowersByPage,
             .activeUserFollowingByPage:
            return APIHTTPMethod.GET.rawValue
            
        case .listShotsByPagePerpage,
             .listShotsByPagePerpageCustomSearch:
            return APIHTTPMethod.GET.rawValue
            
        case .listUserShotsByPage,
             .listUserLikesByPage,
             .listUserFollowersByPage,
             .listUserFollowingByPage:
            return APIHTTPMethod.GET.rawValue
            
        case .listShotCommentsByPage:
            return APIHTTPMethod.GET.rawValue
            
        case .likeComment:
            return APIHTTPMethod.POST.rawValue
            
        case .unlikeComment:
            return APIHTTPMethod.DELETE.rawValue
            
        default:
            return nil
        }
    }
}
