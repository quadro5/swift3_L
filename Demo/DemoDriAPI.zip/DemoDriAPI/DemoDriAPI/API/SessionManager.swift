//
//  SessionManager.swift
//  DemoDriAPI
//
//  Created by PSL on 5/10/17.
//  Copyright © 2017 PSL. All rights reserved.
//

import Foundation
import Alamofire

class SessionManager {
    private init() { }
    static let shared = SessionManager()
    let mgr = Alamofire.SessionManager()
}
