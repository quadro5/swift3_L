//
//  ViewController.swift
//  DemoDriAPI
//
//  Created by PSL on 5/10/17.
//  Copyright © 2017 PSL. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        testRequest()
        
        
    }

    private func testRequest() {
        let client = AlamoClient()
        let request = APIRequest(with: .listShotsByPagePerpage(1, 1))
        let success: (Data?, Int?) -> () = {
            (data, code) -> () in
            guard let data = data else {
                return
            }
            guard let jsonObj = try? JSONSerialization.jsonObject(with: data, options: []) as?  [Any] else {
                return
            }
            let jsonOne = jsonObj?[0] as? [String: Any]
            print("jsonObj: \(jsonOne)")
            print("code: \(code)")
        }
        let failure: (Error?) -> () = {
            (error) -> () in
            guard let error = error else {
                return
            }
            print("Error: \(error.localizedDescription)")
        }
        client.send(request: request, success: success, failure: failure)
    }
}

