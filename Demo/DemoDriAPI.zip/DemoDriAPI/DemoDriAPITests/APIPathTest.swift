//
//  APIPathTest.swift
//  DemoDriAPI
//
//  Created by PSL on 5/10/17.
//  Copyright © 2017 PSL. All rights reserved.
//

import XCTest
@testable import DemoDriAPI

class APIPathTest: XCTestCase {
    override func setUp() {
        super.setUp()
    }
    
    override func tearDown() {
        super.tearDown()
    }

    func testLikeShot() {
        guard let path = APIPath.build(with: .likeShot(0)) else {
            XCTAssert(false)
            return
        }
        let idealPath = IdealPaths.likeShot
        XCTAssertEqual(path, idealPath)
    }
    
    func testCheckLikeShot() {
        guard let path = APIPath.build(with: .checkLikeShot(0)) else {
            XCTAssert(false)
            return
        }
        let idealPath = IdealPaths.checkLikeShot
        XCTAssertEqual(path, idealPath)
    }
    
    func testUnlikeShot() {
        guard let path = APIPath.build(with: .unlikeShot(0)) else {
            XCTAssert(false)
            return
        }
        let idealPath = IdealPaths.unlikeShot
        XCTAssertEqual(path, idealPath)
    }
    
    func testActiveUser() {
        guard let path = APIPath.build(with: .activeUser) else {
            XCTAssert(false)
            return
        }
        let idealPath = IdealPaths.activeUser
        XCTAssertEqual(path, idealPath)
    }
    
    func testActiveUserLikesByPage() {
        guard let path = APIPath.build(with: .activeUserLikesByPage(0)) else {
            XCTAssert(false)
            return
        }
        let idealPath = IdealPaths.activeUserLikesByPage
        XCTAssertEqual(path, idealPath)
    }
    
    func testActiveUserShotsByPage() {
        guard let path = APIPath.build(with: .activeUserShotsByPage(0)) else {
            XCTAssert(false)
            return
        }
        let idealPath = IdealPaths.activeUserShotsByPage
        XCTAssertEqual(path, idealPath)
    }
    
    func testActiveUserFollowersByPage() {
        guard let path = APIPath.build(with: .activeUserFollowersByPage(0)) else {
            XCTAssert(false)
            return
        }
        let idealPath = IdealPaths.activeUserFollowersByPage
        XCTAssertEqual(path, idealPath)
    }
    
    func testActiveUserFollowingByPage() {
        guard let path = APIPath.build(with: .activeUserFollowingByPage(0)) else {
            XCTAssert(false)
            return
        }
        let idealPath = IdealPaths.activeUserFollowingByPage
        XCTAssertEqual(path, idealPath)
    }
    
    func testListUserLikesByPage() {
        guard let path = APIPath.build(with: .listUserLikesByPage(0,1)) else {
            XCTAssert(false)
            return
        }
        let idealPath = IdealPaths.listUserLikesByPage
        XCTAssertEqual(path, idealPath)
    }
    
    func testListUserShotsByPage() {
        guard let path = APIPath.build(with: .listUserShotsByPage(0,1)) else {
            XCTAssert(false)
            return
        }
        let idealPath = IdealPaths.listUserShotsByPage
        XCTAssertEqual(path, idealPath)
    }
    
    func testListUserFollowersByPage() {
        guard let path = APIPath.build(with: .listUserFollowersByPage(0,1)) else {
            XCTAssert(false)
            return
        }
        let idealPath = IdealPaths.listUserFollowersByPage
        XCTAssertEqual(path, idealPath)
    }
    
    func testListUserFollowingByPage() {
        guard let path = APIPath.build(with: .listUserFollowingByPage(0,1)) else {
            XCTAssert(false)
            return
        }
        let idealPath = IdealPaths.listUserFollowingByPage
        XCTAssertEqual(path, idealPath)
    }
    
    func testListShotsByPagePerpage() {
        guard let path = APIPath.build(with: .listShotsByPagePerpage(0,1)) else {
            XCTAssert(false)
            return
        }
        let idealPath = IdealPaths.listShotsByPagePerpage
        XCTAssertEqual(path, idealPath)
    }
    
    func testListShotsByPagePerpageCustomSearch() {
        guard let path = APIPath.build(with: .listShotsByPagePerpageCustomSearch(0,1,String(2))) else {
            XCTAssert(false)
            return
        }
        let idealPath = IdealPaths.listShotsByPagePerpageCustomSearch
        XCTAssertEqual(path, idealPath)
    }
    
    func testListShotCommentsByPage() {
        guard let path = APIPath.build(with: .listShotCommentsByPage(0,1)) else {
            XCTAssert(false)
            return
        }
        let idealPath = IdealPaths.listShotCommentsByPage
        XCTAssertEqual(path, idealPath)
    }
    
    func testLikeComment() {
        guard let path = APIPath.build(with: .likeComment(0,1)) else {
            XCTAssert(false)
            return
        }
        let idealPath = IdealPaths.likeComment
        XCTAssertEqual(path, idealPath)
    }
    
    func testUnlikeComment() {
        guard let path = APIPath.build(with: .unlikeComment(0,1)) else {
            XCTAssert(false)
            return
        }
        let idealPath = IdealPaths.unlikeComment
        XCTAssertEqual(path, idealPath)
    }

}



fileprivate struct IdealPaths {
    static let likeShot = "shots/0/like"
    static let checkLikeShot = "shots/0/like"
    static let unlikeShot = "shots/0/like"
    
    // Int: shotId or commentId
    static let activeUser = "user"
    static let activeUserCheckShotLike = "shots/0/like"
    static let activeUserCheckCommentLike = "shots/0/comments/0/like"
    
    // Int: page
    static let activeUserLikesByPage = "user/likes?page=0"
    static let activeUserShotsByPage = "user/shots?page=0"
    static let activeUserFollowersByPage = "user/followers?page=0"
    static let activeUserFollowingByPage = "user/following?page=0"
    
    // Int: userID, page
    static let listUserLikesByPage = "users/0/likes?page=1"
    static let listUserShotsByPage = "users/0/shots?page=1"
    static let listUserFollowersByPage = "users/0/followers?page=1"
    static let listUserFollowingByPage = "users/0/following?page=1"
    
    // Int: page, perpage
    static let listShotsByPagePerpage = "shots?page=0&per_page=1"
    static let listShotsByPagePerpageCustomSearch = "shots?page=0&per_page=1&sort=2"
    
    // shotID, page
    static let listShotCommentsByPage = "shots/0/comments?page=1"
    
    // shotID, commentID
    static let likeComment = "shots/0/comments/1/like"
    static let unlikeComment = "shots/0/comments/1/like"
}
