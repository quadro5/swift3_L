//
//  TESTAlamoClient.swift
//  DemoDriAPI
//
//  Created by PSL on 5/10/17.
//  Copyright © 2017 PSL. All rights reserved.
//

import XCTest
@testable import DemoDriAPI

class AlamoClientTest: XCTestCase {
    
    var client: AlamoClient?

    override func setUp() {
        super.setUp()
        client = AlamoClient()
    }
    
    override func tearDown() {
        // Put teardown code here. This method is called after the invocation of each test method in the class.
        super.tearDown()
        client = nil
    }
    
    func testShotsList() {
        // This is an example of a functional test case.
        // Use XCTAssert and related functions to verify your tests produce the correct results.
        let exp = expectation(description: "Async Test listShotsByPagePerpage(1, 1)")
        
        
        let request = APIRequest(with: .listShotsByPagePerpage(1, 1))
        client?.send(request: request, success: {
            (data, code) in
            XCTAssertNotNil(data)
            XCTAssertNotNil(code)
            
            let jsonData = try! JSONSerialization.jsonObject(with: data!, options: []) as? [Any]
            XCTAssertNotNil(jsonData)
            exp.fulfill()
        
        }, failure: {
            (error) in
            XCTAssertNotNil(error)
            exp.fulfill()
        })
        self.waitForExpectations(timeout: 5, handler: nil)
    }
}
